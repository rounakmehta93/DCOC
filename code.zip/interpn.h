int find_neighbors(float x, float *x_grid, int n);
float inter(float t, float a0, float a1);
float four_d_interp(float *x);
int find_nearest_neighbor(float x, float *x_grid, float x_step,  int n, float shift);
